> Proposer un découpage en composants ReactJS du code HTML de la maquette. 

- Donner la liste énumérée des composants et leur role dans l'IHM. 
- Mentionner les "props" attendues et leur raison pour chaque composant.
- Créer dans le fichier courant "OBJECTIF.md" le plan de l'arbre des composants.